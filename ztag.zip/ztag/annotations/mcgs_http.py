#!/usr/bin/env python
# -*- coding:utf-8 -*-
from ztag.annotation import *


class Mcgs(Annotation):
    # 新增的finger，厂商名称:"昆仑通态",协议:"HTTP",厂商英文名称：“MCGS”
    # Finger in HTTP for MCGS
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj['headers']['server']
        if "MCGS-HttpSvr".lower() in server.lower():
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.MCGS
            meta.global_metadata.device_type = Type.CFS
            meta.local_metadata.product = "MCGS"
            return meta