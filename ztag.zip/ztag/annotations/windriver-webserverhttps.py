from ztag.annotation import *


class EigWebServer(Annotation):
    '''WindRiver-WebServer '''
    protocol = protocols.HTTPS
    subprotocol = protocols.HTTPS.TLS
    port = None

    def process(self, obj, meta):
        server = obj['headers']['server']
        # print server.lower()
        if 'windriver-webserver' in server.lower():
            meta.global_metadata.manufacturer = Manufacturer.WIND_RIVER
            meta.global_metadata.device_type = Type.INDUSTRIAL_CONTROL
            return meta