from ztag.annotation import *


class DahuaWebs(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        if "<title>WEB SERVICE</title>" in obj['body']:
            metaflag = True
        elif 'css/playback.css?version=2.400' in obj['body']:
            metaflag = True
        else:
            pass

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.DAHUA
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = Manufacturer.DAHUA+"-"+"Dahua-Webs"
            return meta