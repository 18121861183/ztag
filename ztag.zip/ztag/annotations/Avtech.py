#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2015-2016 By LLQ. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""

from ztag.annotation import *


class Avtech(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["headers"]["server"]
        if "avtech/1.0" in server.lower():
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.AVTECH  # 增加厂商Avtech，台湾升泰科技
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = Manufacturer.AVTECH+"-"+"Avtech-IP-Camera"
            return meta