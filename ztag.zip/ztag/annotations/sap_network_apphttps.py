from ztag.annotation import *

class EigWebServer(Annotation):
    '''SAP NetWeaver Application Server'''
    protocol = protocols.HTTPS
    subprotocol = protocols.HTTPS.TLS
    port = None
    def process(self, obj, meta):
        server = obj['headers']['server']
        if 'sap netweaver application server' in server.lower():
            meta.global_metadata.manufacturer = Manufacturer.SAP
            meta.global_metadata.device_type = Type.INDUSTRIAL_CONTROL
            return meta