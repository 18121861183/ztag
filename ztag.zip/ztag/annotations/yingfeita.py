from ztag.annotation import *


class Yingfeita(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["header"]["server"]
        if "Infinova-Webs" in server.lower():
            metaflag = True
        elif 'Infinova Command Client' in obj['body']:
            metaflag = True
        else:
            pass

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.YINGFEITA
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Infinova"
            return meta