#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2015-2016 By W.HHH. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""

from ztag.annotation import *


class TiandyWebs(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        flag1 = "Net Video Browser"
        flag2 = 'name=\"TiandyVideo\" id=\"NvsVideo\"'
        if (flag1 in obj['title']) or (flag2 in obj['body']):
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.TIANDY
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Tiandy-Webs"
            return meta

        # print(obj['title'])

        metaflag1 = False
        if "视频监控平台" in obj['title']:
            meta.global_metadata.device_type = Type.CAMERA
            metaflag1 = True

        metaflag2 = False
        if metaflag1 and "Easy7" in obj['content']:
            meta.global_metadata.manufacturer = Manufacturer.Tiandy
            meta.local_metadata.product = "Easy7"
            metaflag2 = True

        if metaflag1 or metaflag2:
            return meta