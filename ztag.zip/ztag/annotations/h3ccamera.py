#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2015-2016 By W.HHH. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""

from ztag.annotation import *


class H3CCamera(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        if "H3C视频监控系统" == obj['title']:
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = "H3C"
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "H3C Video Monitoring System"
            return meta