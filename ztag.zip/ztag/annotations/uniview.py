from ztag.annotation import *


class UniviewWebs(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["headers"]["server"]
        if "unisvr" in server.lower():
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = "uniview"
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Uniview-Webs"
            return meta