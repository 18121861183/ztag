#!/usr/bin/env python
# -*- coding:utf-8 -*-
from ztag.annotation import *
class IPCConfig(Annotation):
    # IPCConfig.exe是许多厂商web端需要安装的控件，无法区分厂商
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port =None
    def process(self, obj, meta):
        metaflag = False
        content = obj['body']
        if "ipcconfig.exe".lower() in content.lower():
            metaflag =True
        if metaflag:
            meta.global_metadata.manufacturer = ""
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = ""
            return meta