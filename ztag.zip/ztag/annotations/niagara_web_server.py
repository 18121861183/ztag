from ztag.annotation import *

class EigWebServer(Annotation):
    '''Niagara Web Server '''
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        server = obj['headers']['server']
        if 'niagara web server' in server.lower():
            # print('Niagara Web Server ')
            meta.global_metadata.manufacturer = Manufacturer.TRIDIUM
            meta.global_metadata.device_type = Type.INDUSTRIAL_CONTROL
            return meta