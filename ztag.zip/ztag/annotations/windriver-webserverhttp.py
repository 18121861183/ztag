from ztag.annotation import *


class EigWebServer(Annotation):
    '''WindRiver-WebServer '''
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        server = obj['headers']['server']
        if 'windriver-webserver' in server.lower():
            # print 'WindRiver-WebServer'
            meta.global_metadata.manufacturer = Manufacturer.WIND_RIVER
            meta.global_metadata.device_type = Type.INDUSTRIAL_CONTROL
            return meta