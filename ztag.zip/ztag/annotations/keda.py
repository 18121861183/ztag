from ztag.annotation import *


class KedaWebs(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["header"]["server"]
        if "kedacom-webs" in server.lower():
            metaflag = True

        if 'Suzhou Keda' in obj['boday'] and 'NVR 3.0' in obj['boday']:
            metaflag = True
        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.KEDA
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Kedacom-webs"
            return meta