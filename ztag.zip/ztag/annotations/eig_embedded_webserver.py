from ztag.annotation import *


class EigWebServer(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        server = obj['headers']['server']

        if 'eig embedded web server' in server.lower():
            meta.global_metadata.manufacturer = Manufacturer.EIG
            meta.global_metadata.device_type = Type.INDUSTRIAL_CONTROL
            return meta