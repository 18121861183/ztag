#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2015-2016 By LLQ. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""

from ztag.annotation import *


class geovision(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["headers"]["server"]
        if "geohttpserver" in server.lower():
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.GEOVISION  # 增加厂商Geovision，台湾奇偶科技
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = Manufacturer.GEOVISION+"-"+"Geovision-IP-Camera"
            return meta