#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
Copyright (c) 2015-2016 By LLQ. All rights reserved.
See the file 'docs/COPYING' for copying permission
"""

from ztag.annotation import *


class Netwave(Annotation):
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        server = obj["headers"]["server"]
        if "netwave ip camera" in server.lower():
            metaflag = True

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.NETWAVE  # 增加厂商Netwave
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Netwave IP Camera"
            return meta