from ztag.annotation import *


class DahuaWebs(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        if "DVR IE" in obj['body']:
            metaflag = True
        elif 'id=DvrClientOCX' in obj['body']:
            metaflag = True
        else:
            pass

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.HANBANGGAOKE
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "Hanbanggaoke-DVR"
            return meta