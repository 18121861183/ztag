from ztag.annotation import *


class TPLink(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None
    def process(self, obj, meta):
        metaflag = False
        flag1 = 'href="../web-static/images/icon.ico'
        flag2 = 'href="../web-static/dynaform/class.css'
        if (flag1 in obj['body'] and flag2 in obj['body']):
            metaflag = True

            # print "this TP-Link IPC"
        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.TPLINK
            meta.global_metadata.device_type = Type.CAMERA
            meta.local_metadata.product = "TP-Link"
            return meta