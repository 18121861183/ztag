#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by iFantastic on 19-2-1
import json
import re
from ztag.annotation import Annotation
from ztag import protocols, sqlite_util
import eventlet
import hyperscan
import sys  # 1

reload(sys)  # 2
sys.setdefaultencoding('utf-8')  # 3

rules_mapper = dict()
banner_mapper = dict()
patterns = []


def init_mapper():
    result = sqlite_util.Database().query_rules(FtpCommon.name)
    for rule in result.fetchall():
        rules_mapper[rule.__getitem__(0)] = rule
        print rule.__getitem__(2)
        patterns.append((bytes(rule.__getitem__(2)), int(rule.__getitem__(0)), hyperscan.HS_FLAG_DOTALL))


def callback(_id, offset_start, offset_end, flag, content):
    banner_mapper[content] = (_id, offset_start, offset_end)


def fetch(_str):
    if len(patterns) == 0:
        init_mapper()
    db = hyperscan.Database()
    expressions, ids, flags = zip(*patterns)
    db.compile(expressions=expressions, ids=ids, elements=len(patterns), flags=flags)
    db.scan(data=str(_str).encode("utf-8"), match_event_handler=callback, context=str(_str).encode("utf8"))


class FtpCommon(Annotation):
    name = "colasoft_ftp"
    protocol = protocols.FTP
    subprotocol = protocols.FTP.BANNER
    port = None

    def read_rule(self):
        pass

    column = ['manufacturer',
              'product',
              'version',
              'revision',
              'description',
              'manufacturer',
              'product',
              'version',
              'revision',
              'os',
              'os_version',
              'os_description',
              'device_type',
              'description']

    index_number = range(6, 20)

    def is_json(self, myjson):
        try:
            right=json.loads(myjson)
        except ValueError:
            return None
        return right

    def match(self, rule, banner):
        obj = self.is_json(rule)
        if obj is not None:
            if obj.keys().__contains__('regex'):
                match = re.compile(obj['regex']).match(banner)
                if match is not None:
                    return match.group(1)
                else:
                    return None
        else:
            return obj

    def process(self, obj, meta):
        banner = obj["banner"]

        # 不带返回结果的异步
        pool = eventlet.GreenPool()
        pile = eventlet.GreenPile(pool)
        pile.spawn(fetch, banner)
        pool.waitall()
        if len(banner_mapper.keys()) > 0:
            _id, offset_start, offset_end = banner_mapper[banner]
            if _id is not None:
                rule = rules_mapper.get(_id)
                if rule is not None:
                    # match result success
                    # for index, cloumn in zip(self.index_number, self.column):
                    #     value = rule.__getitem__(index)
                    #     if value is not None:
                    #         rule_obj = self.is_json(value)
                    #         if rule_obj is not None:
                    #             if rule_obj.keys().__contains__('regex'):
                    #                 match = re.compile(rule_obj['regex']).match(banner)
                    #                 if match is not None:
                    #                     if index > 10:
                    #                         meta.metadata[cloumn] = match.group(1)
                    #                     else:
                    #                         meta.local_metadata[cloumn] = match.group(1)
                    #         else:
                    #             if index > 10:
                    #                 meta.metadata[cloumn] = str(value)
                    #             else:
                    #                 mapper[cloumn] = value
                    #
                    # return meta
                    meta.local_metadata.manufacturer = banner[offset_start:offset_end]
                    # meta.local_metadata.product
                    # meta.local_metadata.version
                    # meta.local_metadata.revision
                    # meta.local_metadata._description
                    #
                    # meta.global_metadata.manufacturer
                    # meta.global_metadata.product
                    # meta.global_metadata.version
                    # meta.global_metadata.revision
                    # meta.global_metadata.os
                    # meta.global_metadata.os_version
                    # meta.global_metadata.os_description
                    # meta.global_metadata.device_type
                    # meta.global_metadata._description
                return meta

