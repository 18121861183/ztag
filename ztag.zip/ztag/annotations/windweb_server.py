from ztag.annotation import *

class EigWebServer(Annotation):
    '''WindWeb'''
    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        server = obj['headers']['server']
        if 'windweb' in server.lower():
            meta.global_metadata.manufacturer = Manufacturer.NRG_SYSTEMS
            meta.global_metadata.device_type = Type.RTU
            meta.local_metadata.product = "Windcube"
            return meta