from ztag.annotation import *


class UniviewWebs(Annotation):

    protocol = protocols.HTTP
    subprotocol = protocols.HTTP.GET
    port = None

    def process(self, obj, meta):
        metaflag = False
        if "windweb" in obj["banner"].lower():
            metaflag = True
        else:
            pass

        if metaflag:
            meta.global_metadata.manufacturer = Manufacturer.NRG_SYSTEMS
            meta.global_metadata.device_type = Type.RTU
            meta.local_metadata.product = Manufacturer.NRG_SYSTEMS+"-"+"Windcube"
            return meta